import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { UsermoduleComponent } from './usermodule/usermodule.component';
import { UserroutingComponent } from './userrouting/userrouting.component';
import { UserservieComponent } from './userservie/userservie.component';

const routes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'user', component: UserComponent },
    { path: 'explainmodule', component: UsermoduleComponent },
    { path: 'explainrouting', component: UserroutingComponent },
    { path: 'explainservices', component: UserservieComponent }

];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
