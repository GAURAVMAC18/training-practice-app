import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { UsermoduleComponent } from './usermodule/usermodule.component';
import { UserroutingComponent } from './userrouting/userrouting.component';
import { UserservieComponent } from './userservie/userservie.component';
import { TestComponent } from './test/test.component';

@NgModule({
    declarations: [
        AppComponent,
        UserComponent,
        HomeComponent,
        UsermoduleComponent,
        UserroutingComponent,
        UserservieComponent,
        TestComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        HttpClientModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
