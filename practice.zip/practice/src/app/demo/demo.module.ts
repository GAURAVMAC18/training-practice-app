import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Test2Component } from './test2/test2.component';
import { Demo2Module } from '../demo2/demo2.module';



@NgModule({
    declarations: [Test2Component],
    imports: [
        CommonModule,
        Demo2Module
    ]
})
export class DemoModule { }
