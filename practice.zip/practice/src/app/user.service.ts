import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class UserService {

    constructor(
        private httpClient: HttpClient
    ) { }

    saveData(requestDto: any) {
        return this.httpClient.post('api-url', requestDto);
    }
    getData() {
        return this.httpClient.get('api-url');
    }
    updateData(requestDto: any) {
        return this.httpClient.put('api-url', requestDto);
    }
    deleteData() {
        return this.httpClient.delete('api-url');
    }

}
