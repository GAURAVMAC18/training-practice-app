import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-user',
    templateUrl: './user.component.html',
    styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
    userName: string = 'demo user';
    declareVariable: any = `
        userName: string = 'demo user';<br>
        age: number = 20;<br>
        isActive: boolean = true;<br>
        email: any = 'demouser@yopmail.com';
    `;

    printVariable: any = `
        <label>User Name</label> : {{userName}}
    `;

    createFunction: any = `
        getUserDetails(){<br>
            &nbsp;&nbsp; let userData = "new user details";<br>
            &nbsp;&nbsp; return userData;<br>
        }<br><br>
        Call Function : this.getUserDetails();
    `;
    accessFunction: any = `
        <label>User Details</label> : {{getUserDetails()}}
    `;

    constructor() { }

    ngOnInit(): void {
    }

    getUserDetails() {
        let userData = "new user details";
        return userData;
    }

}
