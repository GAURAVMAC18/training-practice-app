import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-usermodule',
    templateUrl: './usermodule.component.html',
    styleUrls: ['./usermodule.component.css']
})
export class UsermoduleComponent implements OnInit {
    imports: any = `
        import { BrowserModule } from '@angular/platform-browser';<br>
        import { HttpClientModule } from '@angular/common/http';<br>
        import { UserComponent } from './user/user.component';<br>
        import { UserService } from './user.service';
        `;

    properties = `
    @NgModule({<br>
        &nbsp;&nbsp; imports:      [ BrowserModule, HttpClientModule ], <br>
        &nbsp;&nbsp; providers:    [ UserService ], <br>
        &nbsp;&nbsp; declarations: [ UserComponent, practiceDirective ],<br>
        &nbsp;&nbsp; exports:      [ UserComponent, practiceDirective ]<br>
      })
    `;

    constructor() { }

    ngOnInit(): void {
    }

}
