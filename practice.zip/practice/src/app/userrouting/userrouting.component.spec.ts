import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserroutingComponent } from './userrouting.component';

describe('UserroutingComponent', () => {
  let component: UserroutingComponent;
  let fixture: ComponentFixture<UserroutingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserroutingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserroutingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
