import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-userrouting',
    templateUrl: './userrouting.component.html',
    styleUrls: ['./userrouting.component.css']
})
export class UserroutingComponent implements OnInit {
    createRoutes: any = `
    const routes: Routes = [<br>
        &nbsp;&nbsp; { path: '', component: HomeComponent },<br>
        &nbsp;&nbsp; { path: 'user', component: UserComponent },<br>
        &nbsp;&nbsp; {<br>
            &nbsp;&nbsp; &nbsp;&nbsp; path: 'first-component',<br>
            &nbsp;&nbsp; &nbsp;&nbsp; component: FirstComponent, // this is the parent route<br>
            &nbsp;&nbsp; &nbsp;&nbsp; children: [<br>
                &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; {<br>
                    &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; path: 'child-a', // child route path<br>
                    &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; component: ChildAComponent, // child route component that the router renders<br>
                    &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; }<br>
                    &nbsp;&nbsp; &nbsp;&nbsp;  ],<br>
    ];<br><br>
    
    @NgModule({<br>
        &nbsp;&nbsp; imports: [RouterModule.forRoot(routes)],<br>
        &nbsp;&nbsp; exports: [RouterModule]<br>
    })
    `;
    constructor() { }

    ngOnInit(): void {
    }

}
