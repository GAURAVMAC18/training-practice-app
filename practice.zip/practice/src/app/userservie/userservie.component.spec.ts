import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserservieComponent } from './userservie.component';

describe('UserservieComponent', () => {
  let component: UserservieComponent;
  let fixture: ComponentFixture<UserservieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserservieComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserservieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
