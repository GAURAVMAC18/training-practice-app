import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserService } from '../user.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-userservie',
    templateUrl: './userservie.component.html',
    styleUrls: ['./userservie.component.css']
})
export class UserservieComponent implements OnInit, OnDestroy {
    userSubscription: Subscription;
    userData = null;

    imports: any = `
    import { HttpClient } from '@angular/common/http';
        `;

    apiMethods = `
    saveData(requestDto: any) {<br>
        &nbsp;&nbsp; return this.httpClient.post('api-url', requestDto);<br>
    }<br><br>
    getData() {<br>
        &nbsp;&nbsp; return this.httpClient.get('api-url');<br>
    }<br><br>
    updateData(requestDto: any) {<br>
        &nbsp;&nbsp; return this.httpClient.put('api-url', requestDto);<br>
    }<br><br>
    deleteData() {<br>
        &nbsp;&nbsp;  return this.httpClient.delete('api-url');<br>
    }
        `;

    apiMethodsCall = `
    import { UserService } from './user.service';<br>
    import { Subscription } from 'rxjs';<br><br>
    <b>// -- Define user service in component constructor</b><br>
        private userService: UserService<br><br>

        <b>// -- implement user service methods in component</b><br>
        userSubscription: Subscription;<br>
        getUserDetails() {<br>
            &nbsp;&nbsp; &nbsp;&nbsp; this.userSubscription = this.userService.getData().subscribe(<br>
                &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; (response: any) => {<br>
                    &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; this.userData = response<br>
                    &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; }<br>
                    &nbsp;&nbsp; &nbsp;&nbsp; );<br>
        }<br><br>

        <b>// -- Destroy api subscription when component switch to aviod browser memory leakage issue</b><br>
        ngOnDestroy(): void {<br>
            &nbsp;&nbsp; if (this.userSubscription) {<br>
                &nbsp;&nbsp; &nbsp;&nbsp; this.userSubscription.unsubscribe();<br>
                &nbsp;&nbsp; }<br>
        }<br>
        `;

    constructor(
        private userService: UserService
    ) { }

    ngOnInit(): void {
    }

    getUserDetails() {
        this.userSubscription = this.userService.getData().subscribe(
            (response: any) => {
                this.userData = response
            }
        );
    }

    ngOnDestroy(): void {
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
    }


}
